export const DocsUrl = "https://docs.opensaas.sh";
export const BlogUrl = "https://docs.opensaas.sh/blog";
